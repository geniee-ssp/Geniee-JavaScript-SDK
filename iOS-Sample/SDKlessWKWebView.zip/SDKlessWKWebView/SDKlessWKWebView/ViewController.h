//
//  ViewController.h
//  SDKless2
//
//  Created by Takahashi Naoki on 2016/03/30.
//  Copyright © 2016年 Geniee Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
